# Hamk (app Android)

IA pessoal que roda 100% no celular, sem API de ninguém.

- **Cérebro local**: modelo aberto (Gemma 3n .task) rodando dentro do app via MediaPipe. Você escolhe o arquivo uma vez.
- **Vê fotos** (com Gemma 3n) e, se o modelo não enxergar, lê o texto da imagem (OCR offline).
- **Voz**: fala as respostas e conversa por voz (ouve, responde, volta a ouvir). Microfone só liga por toque seu.
- **Aprende**: memória própria no celular. "Lembre que..." guarda um fato; ele também estuda a Wikipédia e links que você mandar (sem chave de API).
- **Online e offline**: com internet pesquisa e aprende; sem internet usa o modelo e a memória.
- **Modo Programador**: gera arquivos de código, monta ZIP do projeto e mostra prévia do site.
- **Ateliê**: o Hamk pinta com código (SVG), sem limite, e você também pode pintar à mão. Salva PNG/SVG.
- APK compilado automaticamente pelo GitHub Actions (`.github/workflows/build-apk.yml`).

## Créditos e licenças
- MediaPipe (Apache 2.0) e ML Kit (termos do Google). O modelo Gemma segue a licença do Gemma.
- Todo o código do app foi escrito do zero para este projeto.

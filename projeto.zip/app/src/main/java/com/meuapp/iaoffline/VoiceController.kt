package com.meuapp.iaoffline

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Voz do Hamk. Ouvir e falar preferem funcionar offline.
 * ouvir() EXIGE um ComandoDoChefe: o microfone nunca liga sozinho.
 * Chame ouvir() e pararDeOuvir() sempre na thread principal.
 */
class VoiceController(private val ctx: Context) {

    private var reconhecedor: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private val principal = Handler(Looper.getMainLooper())
    private var aoTerminarFala: (() -> Unit)? = null

    fun iniciarTts() {
        if (tts != null) return
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale.forLanguageTag("pt-BR"))
                ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        terminouFala()
                    }
                    override fun onError(utteranceId: String?) {
                        terminouFala()
                    }
                })
            }
        }
    }

    private fun terminouFala() {
        principal.post {
            val cb = aoTerminarFala
            aoTerminarFala = null
            cb?.invoke()
        }
    }

    private fun limparParaFala(texto: String): String {
        var t = Regex("```.*?```", RegexOption.DOT_MATCHES_ALL).replace(texto, " (código omitido). ")
        t = t.replace("*", "").replace("#", "").replace("`", "")
        return t.trim()
    }

    fun falar(texto: String, aoTerminar: (() -> Unit)? = null) {
        val limpo = limparParaFala(texto)
        if (!ttsOk || limpo.isBlank()) {
            if (aoTerminar != null) principal.post { aoTerminar() }
            return
        }
        aoTerminarFala = aoTerminar
        tts?.speak(limpo.take(3500), TextToSpeech.QUEUE_FLUSH, null, "hamk-fala")
    }

    fun calar() {
        aoTerminarFala = null
        try { tts?.stop() } catch (_: Throwable) {}
    }

    fun disponivelParaOuvir(): Boolean = SpeechRecognizer.isRecognitionAvailable(ctx)

    @Suppress("UNUSED_PARAMETER")
    fun ouvir(
        comando: ComandoDoChefe,
        onParcial: (String) -> Unit,
        onTexto: (String) -> Unit,
        onFim: (String?) -> Unit
    ) {
        pararDeOuvir()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        reconhecedor = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                onFim(mensagemErro(error))
                liberarDepois()
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                onFim(null)
                if (!t.isNullOrBlank()) onTexto(t)
                liberarDepois()
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onParcial(t)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        r.startListening(intent)
    }

    fun pararDeOuvir() {
        try { reconhecedor?.stopListening() } catch (_: Throwable) {}
        liberarRec()
    }

    private fun liberarDepois() {
        principal.post { liberarRec() }
    }

    private fun liberarRec() {
        try { reconhecedor?.destroy() } catch (_: Throwable) {}
        reconhecedor = null
    }

    fun liberar() {
        liberarRec()
        try { tts?.shutdown() } catch (_: Throwable) {}
        tts = null
    }

    private fun mensagemErro(codigo: Int): String = when (codigo) {
        7 -> "Não entendi o que você falou. Tente de novo."
        6 -> "Não ouvi nada. Fale logo depois de tocar."
        9 -> "Sem permissão do microfone."
        12, 13 -> "O Android ainda não tem o pacote de voz em português baixado. " +
            "Vá em Configurações do Android > Idioma e entrada de voz e baixe o português para uso offline."
        2, 1 -> "O reconhecimento de voz precisou de internet e não conseguiu. " +
            "Baixe o pacote de voz offline em português nas Configurações do Android."
        else -> "Erro no reconhecimento de voz (código $codigo)."
    }
}

package com.meuapp.iaoffline

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.util.Locale

data class Fato(val id: String, val texto: String, val fonte: String, val em: Long)

/**
 * Memória do Hamk: tudo o que você ensina e tudo o que ele estuda na internet fica aqui,
 * num arquivo dentro do app. Antes de responder, ele procura nesta memória o que combina com a pergunta.
 */
class Memoria(private val ctx: Context) {

    private var fatos: MutableList<Fato> = carregarDoDisco()

    private fun arquivo(): File = File(ctx.filesDir, "memoria_hamk.json")

    private fun carregarDoDisco(): MutableList<Fato> {
        val lista = mutableListOf<Fato>()
        try {
            val f = arquivo()
            if (f.exists()) {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    lista.add(
                        Fato(
                            o.getString("id"),
                            o.getString("texto"),
                            o.optString("fonte", "você"),
                            o.optLong("em", 0L)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // arquivo estragado: começa vazio
        }
        return lista
    }

    private fun gravar() {
        try {
            val arr = JSONArray()
            for (f in fatos) {
                arr.put(
                    JSONObject().put("id", f.id).put("texto", f.texto)
                        .put("fonte", f.fonte).put("em", f.em)
                )
            }
            arquivo().writeText(arr.toString())
        } catch (e: Exception) {
            // sem espaço: ignora
        }
    }

    @Synchronized
    fun todos(): List<Fato> = fatos.asReversed().toList()

    @Synchronized
    fun adicionar(texto: String, fonte: String) {
        val limpo = texto.trim().take(900)
        if (limpo.length < 3) return
        if (fatos.any { it.texto == limpo }) return
        fatos.add(Fato(novoId(), limpo, fonte, System.currentTimeMillis()))
        while (fatos.size > 1500) fatos.removeAt(0)
        gravar()
    }

    @Synchronized
    fun remover(id: String) {
        fatos = fatos.filter { it.id != id }.toMutableList()
        gravar()
    }

    @Synchronized
    fun buscar(consulta: String, quantos: Int): List<Fato> {
        val q = palavras(consulta)
        if (q.isEmpty()) return emptyList()
        return fatos
            .map { f -> Pair(f, palavras(f.texto).count { it in q }) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(quantos)
            .map { it.first }
    }

    private fun palavras(s: String): Set<String> {
        val n = Normalizer.normalize(s.lowercase(Locale("pt", "BR")), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return Regex("[a-z0-9]{3,}").findAll(n).map { it.value }.filter { it !in PARADAS }.toSet()
    }

    companion object {
        private val PARADAS = setOf(
            "para", "com", "uma", "que", "por", "dos", "das", "nos", "nas", "mais", "como", "isso",
            "esse", "essa", "este", "esta", "voce", "seu", "sua", "meu", "minha", "quem", "qual",
            "quais", "onde", "quando", "sobre", "pelo", "pela", "foi", "sao", "ser", "tem", "ter",
            "era", "muito", "tambem", "mas", "ele", "ela", "eles", "elas", "fale", "diga",
            "pesquise", "busque", "explique", "procure", "me", "uns", "umas", "aos", "num", "numa"
        )
    }
}

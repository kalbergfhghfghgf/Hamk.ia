package com.meuapp.iaoffline

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Lê o texto de uma foto, 100% no aparelho (ML Kit empacotado). Usado quando o modelo não enxerga imagens. */
object OcrHelper {
    fun ler(bitmap: Bitmap, onOk: (String) -> Unit, onErro: (String) -> Unit) {
        try {
            val imagem = InputImage.fromBitmap(bitmap, 0)
            val reconhecedor = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            reconhecedor.process(imagem)
                .addOnSuccessListener { onOk(it.text) }
                .addOnFailureListener { onErro(it.message ?: "Erro ao ler a foto.") }
        } catch (e: Exception) {
            onErro(e.message ?: "Erro ao ler a foto.")
        }
    }
}

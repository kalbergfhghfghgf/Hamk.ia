package com.meuapp.iaoffline

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext
    private val ajustes = AppSettings(ctx)
    private val store = ChatStore(ctx)
    private val engine = LlmEngine(ctx)
    private val memoria = Memoria(ctx)
    val voz = VoiceController(ctx)

    val cfg = MutableStateFlow(ajustes.carregar())
    val tela = MutableStateFlow(Tela.CHAT)
    val modo = MutableStateFlow(Modo.CONVERSA)
    val conversas = MutableStateFlow<List<Conversa>>(emptyList())
    val mensagens = MutableStateFlow<List<Msg>>(emptyList())
    val estadoModelo = MutableStateFlow<EstadoModelo>(EstadoModelo.Nenhum)
    val gerando = MutableStateFlow(false)
    val ouvindo = MutableStateFlow(false)
    val modoVoz = MutableStateFlow(false)
    val entrada = MutableStateFlow("")
    val aviso = MutableStateFlow<String?>(null)
    val foto = MutableStateFlow<Bitmap?>(null)
    val visaoDisponivel = MutableStateFlow(false)
    val memoriaLista = MutableStateFlow<List<Fato>>(emptyList())
    val estudando = MutableStateFlow(false)
    val arte = MutableStateFlow<String?>(null)
    val criandoArte = MutableStateFlow(false)

    private var conversaId: String = novoId()
    private var job: Job? = null
    private var comandoVoz: ComandoDoChefe? = null

    init {
        conversas.value = store.carregar()
        memoriaLista.value = memoria.todos()
        voz.iniciarTts()
        val c = cfg.value
        if (!c.setupFeito) {
            tela.value = Tela.SETUP
        } else if (c.caminhoModelo.isBlank() || !File(c.caminhoModelo).exists()) {
            tela.value = Tela.MODELO
        } else {
            tela.value = Tela.CHAT
            carregarModelo()
        }
    }

    // ---------------------------------------------------------------- configurações

    fun salvarCfg(c: Config) {
        cfg.value = c
        ajustes.salvar(c)
    }

    fun concluirSetup(nomeIa: String, nomeUsuario: String) {
        val c = cfg.value.copy(
            nomeIa = nomeIa.trim().ifBlank { "Hamk" },
            nomeUsuario = nomeUsuario.trim().ifBlank { "Chefe" },
            setupFeito = true
        )
        salvarCfg(c)
        tela.value = if (c.caminhoModelo.isNotBlank() && File(c.caminhoModelo).exists()) Tela.CHAT else Tela.MODELO
        if (tela.value == Tela.CHAT) carregarModelo()
    }

    fun salvarConfigCompleta(novo: Config) {
        val antigo = cfg.value
        salvarCfg(novo.copy(setupFeito = true, caminhoModelo = antigo.caminhoModelo, nomeModelo = antigo.nomeModelo))
        if (novo.maxTokens != antigo.maxTokens && engine.pronto) carregarModelo()
    }

    fun alternarInternet() {
        val c = cfg.value
        salvarCfg(c.copy(internet = !c.internet))
    }

    // ---------------------------------------------------------------- modelo local

    private fun visaoPossivel(c: Config): Boolean {
        val n = c.nomeModelo.lowercase()
        return n.isBlank() || n.contains("3n")
    }

    fun carregarModelo() {
        val c = cfg.value
        if (c.caminhoModelo.isBlank() || !File(c.caminhoModelo).exists()) {
            estadoModelo.value = EstadoModelo.Nenhum
            return
        }
        estadoModelo.value = EstadoModelo.Carregando
        viewModelScope.launch(Dispatchers.IO) {
            try {
                engine.carregar(c.caminhoModelo, c.maxTokens, visaoPossivel(c))
                visaoDisponivel.value = engine.temVisao
                estadoModelo.value = EstadoModelo.Pronto
            } catch (t: Throwable) {
                visaoDisponivel.value = false
                estadoModelo.value = EstadoModelo.Erro(
                    "Não consegui carregar esse modelo. Ele precisa ser um arquivo .task compatível " +
                        "com o MediaPipe. Detalhe: ${t.message}"
                )
            }
        }
    }

    fun importarModelo(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                engine.descarregar()
                estadoModelo.value = EstadoModelo.Copiando(0)
                val resolver = ctx.contentResolver
                var total = -1L
                var nome = ""
                resolver.query(uri, arrayOf(OpenableColumns.SIZE, OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
                    if (cur.moveToFirst()) {
                        total = cur.getLong(0)
                        nome = cur.getString(1) ?: ""
                    }
                }
                val dir = File(ctx.filesDir, "modelos").apply { mkdirs() }
                val destino = File(dir, "modelo.task")
                val tmp = File(dir, "modelo.tmp")
                val entradaStream = resolver.openInputStream(uri)
                    ?: throw IllegalStateException("Não consegui abrir o arquivo escolhido.")
                entradaStream.use { ins ->
                    tmp.outputStream().use { outs ->
                        val buf = ByteArray(1 shl 16)
                        var lido = 0L
                        var ultimo = -1
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            outs.write(buf, 0, n)
                            lido += n
                            if (total > 0) {
                                val p = (lido * 100 / total).toInt()
                                if (p != ultimo) {
                                    ultimo = p
                                    estadoModelo.value = EstadoModelo.Copiando(p)
                                }
                            }
                        }
                    }
                }
                if (destino.exists()) destino.delete()
                tmp.renameTo(destino)
                salvarCfg(cfg.value.copy(caminhoModelo = destino.absolutePath, nomeModelo = nome))
                carregarModelo()
            } catch (t: Throwable) {
                estadoModelo.value = EstadoModelo.Erro("Não consegui copiar o modelo: ${t.message}")
            }
        }
    }

    // ---------------------------------------------------------------- memória e internet

    fun atualizarMemoria() {
        memoriaLista.value = memoria.todos()
    }

    fun ensinar(texto: String) {
        val t = texto.trim()
        if (t.length < 3) return
        memoria.adicionar(t, "ensinado por você")
        atualizarMemoria()
        aviso.value = "Guardei na memória."
    }

    fun esquecer(id: String) {
        memoria.remover(id)
        atualizarMemoria()
    }

    fun estudar(tema: String) {
        val t = tema.trim()
        if (t.length < 2 || estudando.value) return
        if (!cfg.value.internet) {
            aviso.value = "A internet está desligada. Ligue em ⚙️ Configurações ou no chat."
            return
        }
        if (!Web.conectado(ctx)) {
            aviso.value = "Sem conexão agora. Quando tiver internet, tente de novo."
            return
        }
        estudando.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val p = Web.pesquisarWikipedia(t)
                if (p == null) {
                    aviso.value = "Não achei nada sobre isso."
                } else {
                    memoria.adicionar(p.titulo + ": " + p.texto.take(800), "web:" + p.url)
                    atualizarMemoria()
                    aviso.value = "Aprendi sobre: ${p.titulo}"
                }
            } catch (e: Exception) {
                aviso.value = "Não consegui estudar agora: ${e.message}"
            }
            estudando.value = false
        }
    }

    private val prefixosMemoria = listOf(
        "lembre-se que", "lembre que", "guarde que", "guarde:", "aprenda que", "aprenda:",
        "memorize que", "memorize:", "anote que", "anote:"
    )

    private fun comandoDeMemoria(texto: String): String? {
        val l = texto.trim()
        val baixo = l.lowercase()
        for (p in prefixosMemoria) {
            if (baixo.startsWith(p)) {
                val resto = l.substring(p.length).trim(' ', ':', ',')
                if (resto.length >= 3) return resto
            }
        }
        return null
    }

    // ---------------------------------------------------------------- conversa

    fun enviarEntrada() {
        enviar(entrada.value)
    }

    fun pedirIdeias() {
        enviar(
            "Me dê 5 ideias e sugestões práticas sobre o que estamos conversando. " +
                "Se ainda não conversamos sobre nada, sugira o que eu posso fazer com você."
        )
    }

    private class PromptMontado(val antes: String, val depois: String)

    private fun sistemaDoModo(c: Config): String {
        val base = if (modo.value == Modo.PROGRAMADOR) PROMPT_PROGRAMADOR else c.promptSistema
        return base.replace("{nome}", c.nomeIa).replace("{usuario}", c.nomeUsuario)
    }

    /** Monta a conversa no formato do Gemma: turnos "user" e "model". */
    private fun montarPrompt(
        sistema: String,
        contexto: String,
        historico: List<Msg>,
        ultima: String,
        maxTokens: Int
    ): PromptMontado {
        val limite = (maxTokens * 1.5).toInt()
        val cabecalho = sistema + (if (contexto.isNotBlank()) "\n\n" + contexto else "")
        val sb = StringBuilder()
        sb.append("<start_of_turn>user\n").append(cabecalho).append("<end_of_turn>\n")
        sb.append("<start_of_turn>model\nEntendido.<end_of_turn>\n")
        var total = sb.length + ultima.length
        val turnos = ArrayList<String>()
        for (m in historico.asReversed()) {
            if (m.text.isBlank()) continue
            val papel = if (m.role == "user") "user" else "model"
            val turno = "<start_of_turn>$papel\n${m.text.take(limite / 3)}<end_of_turn>\n"
            if (total + turno.length > limite && turnos.isNotEmpty()) break
            if (total + turno.length > limite * 2) break
            turnos.add(turno)
            total += turno.length
        }
        for (t in turnos.asReversed()) sb.append(t)
        sb.append("<start_of_turn>user\n")
        return PromptMontado(sb.toString(), ultima + "<end_of_turn>\n<start_of_turn>model\n")
    }

    private fun limpar(s: String): String =
        s.substringBefore("<end_of_turn>").substringBefore("<start_of_turn>").trimEnd()

    fun enviar(texto: String) {
        val t = texto.trim()
        val bmp = foto.value
        if ((t.isEmpty() && bmp == null) || gerando.value || criandoArte.value) return
        entrada.value = ""
        if (ouvindo.value) pararDeOuvir()
        voz.calar()
        foto.value = null

        val c = cfg.value
        val pergunta = if (t.isEmpty()) "Descreva esta imagem em detalhes." else t
        val caminhoFoto = if (bmp != null) salvarMiniatura(bmp) else null
        val historico = mensagens.value
        val base = historico + Msg("user", pergunta, caminhoFoto)
        mensagens.value = base + Msg("assistant", "")
        gerando.value = true

        val aprender = if (bmp == null) comandoDeMemoria(pergunta) else null
        if (aprender != null) {
            memoria.adicionar(aprender, "ensinado por você")
            atualizarMemoria()
            finalizar(base, "Guardei na minha memória: \"$aprender\"", c)
            return
        }

        job = viewModelScope.launch(Dispatchers.IO) {
            var prefixo = ""
            var contexto = ""

            // 1) memória: o que o Hamk já aprendeu e combina com a pergunta
            val achados = memoria.buscar(pergunta, 3)
            if (achados.isNotEmpty()) {
                contexto += "Memória (coisas que você já aprendeu ou que o chefe ensinou):\n" +
                    achados.joinToString("\n") { "- " + it.texto.take(500) } + "\n\n"
            }

            // 2) internet (sem API): só quando ligada, com conexão, e o pedido pede pesquisa ou traz um link
            if (c.internet && bmp == null && Web.conectado(ctx)) {
                val url = Web.extrairUrl(pergunta)
                val pesquisar = url == null && Web.querPesquisar(pergunta)
                if (url != null || pesquisar) {
                    mensagens.value = base + Msg("assistant", "🔎 pesquisando…")
                    try {
                        if (url != null) {
                            val p = Web.lerPagina(url)
                            contexto += "Conteúdo da página $url:\n${p.texto.take(2500)}\n\n"
                            memoria.adicionar(p.titulo + ": " + p.texto.take(700), "web:" + url)
                        } else {
                            val p = Web.pesquisarWikipedia(Web.limparConsulta(pergunta))
                            if (p != null) {
                                contexto += "Pesquisa na internet (Wikipédia, ${p.titulo}):\n${p.texto.take(1500)}\n\n"
                                memoria.adicionar(p.titulo + ": " + p.texto.take(700), "web:" + p.url)
                            }
                        }
                        atualizarMemoria()
                    } catch (e: Exception) {
                        prefixo = "⚠️ Não consegui acessar a internet agora. Respondi só com o que eu sei.\n\n"
                    }
                }
            }

            if (!engine.pronto) {
                finalizar(
                    base,
                    "A IA local ainda não está carregada. Vá em ⚙️ Configurações e toque em \"Trocar modelo\".",
                    c
                )
                return@launch
            }

            // 3) foto: se o modelo não enxerga, o Hamk lê o texto da imagem
            var imagemParaModelo: Bitmap? = null
            var textoUsuario = pergunta
            if (bmp != null) {
                if (engine.temVisao) {
                    imagemParaModelo = bmp
                } else {
                    val latch = CountDownLatch(1)
                    var lido = ""
                    OcrHelper.ler(bmp, { lido = it; latch.countDown() }, { latch.countDown() })
                    latch.await(20, TimeUnit.SECONDS)
                    prefixo = "ℹ️ Este modelo não enxerga imagens (use o Gemma 3n). Li só o texto da foto.\n\n"
                    textoUsuario = "Texto lido numa foto:\n\"\"\"\n${lido.trim().ifBlank { "(nenhum texto encontrado)" }}\n\"\"\"\n\n$pergunta"
                }
            }

            val montado = montarPrompt(sistemaDoModo(c), contexto, historico, textoUsuario, c.maxTokens)
            engine.gerar(
                montado.antes,
                imagemParaModelo,
                montado.depois,
                c.temperatura,
                onParcial = { p ->
                    if (gerando.value) mensagens.value = base + Msg("assistant", prefixo + limpar(p))
                },
                onFim = { f -> finalizar(base, prefixo + limpar(f), c) },
                onErro = { e -> finalizar(base, prefixo + "⚠️ " + e, c) }
            )
        }
    }

    fun parar() {
        if (!gerando.value) return
        engine.cancelar()
        job?.cancel()
        val atual = mensagens.value
        gerando.value = false
        if (atual.isNotEmpty() && atual.last().role == "assistant") {
            val ultimo = atual.last()
            val lista = atual.dropLast(1) + Msg("assistant", ultimo.text.ifBlank { "(interrompido)" })
            mensagens.value = lista
            salvarConversa(lista)
        }
    }

    private fun finalizar(base: List<Msg>, texto: String, c: Config) {
        if (!gerando.value) return
        val lista = base + Msg("assistant", texto.ifBlank { "(sem resposta)" })
        mensagens.value = lista
        gerando.value = false
        salvarConversa(lista)
        if (modoVoz.value) {
            voz.falar(texto) {
                val cmd = comandoVoz
                if (modoVoz.value && cmd != null && !gerando.value) ouvir(cmd)
            }
        } else if (c.falarRespostas && modo.value == Modo.CONVERSA) {
            voz.falar(texto)
        }
    }

    private fun salvarConversa(lista: List<Msg>) {
        val titulo = lista.firstOrNull { it.role == "user" }?.text
            ?.take(40)?.replace("\n", " ") ?: "Conversa"
        val nova = Conversa(conversaId, titulo, lista, System.currentTimeMillis())
        conversas.value = listOf(nova) + conversas.value.filter { it.id != conversaId }
        store.salvar(conversas.value)
    }

    fun novaConversa() {
        if (gerando.value) {
            aviso.value = "Espere a resposta terminar (ou toque em ⏹) antes de abrir outra conversa."
            return
        }
        conversaId = novoId()
        mensagens.value = emptyList()
        tela.value = Tela.CHAT
    }

    fun abrirConversa(id: String) {
        if (gerando.value) {
            aviso.value = "Espere a resposta terminar (ou toque em ⏹) antes de abrir outra conversa."
            return
        }
        val c = conversas.value.firstOrNull { it.id == id } ?: return
        conversaId = c.id
        mensagens.value = c.msgs
        tela.value = Tela.CHAT
    }

    fun apagarConversa(id: String) {
        conversas.value = conversas.value.filter { it.id != id }
        store.salvar(conversas.value)
        if (id == conversaId && !gerando.value) {
            conversaId = novoId()
            mensagens.value = emptyList()
        }
    }

    // ---------------------------------------------------------------- projeto (modo programador)

    fun arquivosDoProjeto(): List<ArquivoGerado> = Arquivos.doProjeto(mensagens.value)

    fun nomeDoProjeto(): String {
        val primeira = mensagens.value.firstOrNull { it.role == "user" }?.text ?: "projeto hamk"
        return Arquivos.nomeSeguro(primeira)
    }

    // ---------------------------------------------------------------- microfone e câmera (só sob comando)

    fun ouvir(comando: ComandoDoChefe) {
        if (!PoliticaDeControle.microfonePermitido(cfg.value)) {
            aviso.value = "O microfone está desligado em ⚙️ Configurações."
            modoVoz.value = false
            return
        }
        if (!voz.disponivelParaOuvir()) {
            aviso.value = "Este Android não tem reconhecimento de voz disponível."
            modoVoz.value = false
            return
        }
        voz.calar()
        ouvindo.value = true
        val automatico = modoVoz.value
        voz.ouvir(
            comando,
            onParcial = { entrada.value = it },
            onTexto = {
                entrada.value = it
                if (automatico) enviar(it)
            },
            onFim = { erro ->
                ouvindo.value = false
                if (erro != null) {
                    aviso.value = erro
                    if (automatico) {
                        modoVoz.value = false
                        comandoVoz = null
                    }
                }
            }
        )
    }

    fun pararDeOuvir() {
        voz.pararDeOuvir()
        ouvindo.value = false
    }

    /** Liga a conversa por voz: ouve, responde falando e volta a ouvir, até o chefe tocar em parar. */
    fun iniciarModoVoz(comando: ComandoDoChefe) {
        if (gerando.value) return
        comandoVoz = comando
        modoVoz.value = true
        ouvir(comando)
    }

    fun pararModoVoz() {
        modoVoz.value = false
        comandoVoz = null
        voz.calar()
        pararDeOuvir()
    }

    /** Prepara o arquivo da foto. Só devolve algo se o chefe deu o comando e a câmera está permitida. */
    fun novaFotoUri(comando: ComandoDoChefe): Uri? {
        if (comando.origem.isBlank()) return null
        if (!PoliticaDeControle.cameraPermitida(cfg.value)) {
            aviso.value = "A câmera está desligada em ⚙️ Configurações."
            return null
        }
        return try {
            val pasta = File(ctx.cacheDir, "fotos").apply { mkdirs() }
            val arquivo = File(pasta, "foto.jpg")
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", arquivo)
        } catch (e: Exception) {
            aviso.value = "Não consegui preparar a câmera: ${e.message}"
            null
        }
    }

    // ---------------------------------------------------------------- fotos

    fun anexarFoto(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                foto.value = decodificar(uri, 896)
                try { File(ctx.cacheDir, "fotos/foto.jpg").delete() } catch (_: Exception) {}
            } catch (e: Exception) {
                aviso.value = "Não consegui abrir a foto: ${e.message}"
            }
        }
    }

    fun removerFoto() {
        foto.value = null
    }

    private fun decodificar(uri: Uri, maxLado: Int): Bitmap {
        val resolver = ctx.contentResolver
        val medidas = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, medidas) }
        var amostra = 1
        while (medidas.outWidth / amostra > maxLado * 2 || medidas.outHeight / amostra > maxLado * 2) amostra *= 2
        val opcoes = BitmapFactory.Options().apply { inSampleSize = amostra }
        var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opcoes) }
            ?: throw IllegalStateException("Arquivo de imagem inválido.")
        val graus = try {
            resolver.openInputStream(uri)?.use { ins ->
                when (ExifInterface(ins).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) {
            0f
        }
        if (graus != 0f) {
            val m = Matrix().apply { postRotate(graus) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val maior = maxOf(bmp.width, bmp.height)
        if (maior > maxLado) {
            val f = maxLado.toFloat() / maior
            bmp = Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * f).toInt().coerceAtLeast(1),
                (bmp.height * f).toInt().coerceAtLeast(1),
                true
            )
        }
        return bmp
    }

    private fun salvarMiniatura(bmp: Bitmap): String? {
        return try {
            val pasta = File(ctx.filesDir, "miniaturas").apply { mkdirs() }
            val arq = File(pasta, novoId() + ".jpg")
            val maior = maxOf(bmp.width, bmp.height)
            val f = if (maior > 480) 480f / maior else 1f
            val mini = Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * f).toInt().coerceAtLeast(1),
                (bmp.height * f).toInt().coerceAtLeast(1),
                true
            )
            FileOutputStream(arq).use { mini.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            arq.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    // ---------------------------------------------------------------- ateliê (arte em SVG)

    private fun extrairSvg(bruto: String): String? {
        val ini = bruto.indexOf("<svg")
        if (ini < 0) return null
        var svg = bruto.substring(ini)
        val fim = svg.lastIndexOf("</svg>")
        svg = if (fim >= 0) svg.substring(0, fim + 6) else svg + "\n</svg>"
        if (!svg.contains("viewBox")) svg = svg.replaceFirst("<svg", "<svg viewBox=\"0 0 512 512\"")
        return svg
    }

    fun criarArte(pedido: String, refinar: Boolean) {
        val p = pedido.trim()
        if (p.isEmpty() || criandoArte.value || gerando.value) return
        if (!engine.pronto) {
            aviso.value = "Carregue um modelo de IA primeiro (⚙️ Configurações > Trocar modelo)."
            return
        }
        val c = cfg.value
        val anterior = arte.value
        val antes = StringBuilder()
        antes.append("<start_of_turn>user\n")
            .append(PROMPT_ARTE.replace("{nome}", c.nomeIa)).append("\n\n")
        if (refinar && anterior != null) {
            antes.append("Este é o SVG atual:\n").append(anterior.take(5000))
                .append("\n\nFaça esta alteração e devolva o SVG completo: ").append(p)
        } else {
            antes.append("Pedido de arte: ").append(p)
        }
        val depois = "<end_of_turn>\n<start_of_turn>model\n"
        criandoArte.value = true
        viewModelScope.launch(Dispatchers.IO) {
            engine.gerar(
                antes.toString(), null, depois, 0.9f,
                onParcial = { },
                onFim = { f ->
                    val svg = extrairSvg(limpar(f))
                    if (svg == null) aviso.value = "Não consegui desenhar dessa vez. Tente de novo ou descreva de outro jeito."
                    else arte.value = svg
                    criandoArte.value = false
                },
                onErro = { e ->
                    aviso.value = "⚠️ $e"
                    criandoArte.value = false
                }
            )
        }
    }

    fun pararArte() {
        if (!criandoArte.value) return
        engine.cancelar()
        criandoArte.value = false
    }

    override fun onCleared() {
        voz.liberar()
        engine.descarregar()
        super.onCleared()
    }
}

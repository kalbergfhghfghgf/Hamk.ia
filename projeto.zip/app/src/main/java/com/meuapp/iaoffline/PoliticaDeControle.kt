package com.meuapp.iaoffline

/*
 * ============================================================
 *  POLÍTICA DE CONTROLE  —  O USUÁRIO É O CHEFE GERAL
 * ============================================================
 *  Regras deste app (valem para o código inteiro):
 *
 *  1. MICROFONE e CÂMERA SÓ são acionados por um TOQUE do usuário
 *     (ou comando explícito dele). Nunca sozinhos, nunca em
 *     segundo plano, nunca por iniciativa da IA.
 *
 *  2. Para ligar o microfone ou abrir a câmera, o código EXIGE um
 *     objeto "ComandoDoChefe". Esse objeto só é criado dentro de um
 *     clique de botão feito pelo usuário (veja Telas.kt).
 *
 *  3. Nas Configurações existem interruptores "Permitir microfone" e
 *     "Permitir câmera". Desligados, nada funciona.
 *
 *  4. Não existe serviço em segundo plano gravando nada.
 *
 *  5. Áudio e foto nunca saem do aparelho. O texto da conversa só
 *     sai se o chefe ligar o "Modo online".
 *
 *  6. A IA pode SUGERIR usar a câmera/microfone, mas quem decide
 *     é sempre o chefe, tocando no botão.
 * ============================================================
 */

/** Prova de que o chefe mandou. Só é criado a partir de um toque do usuário. */
class ComandoDoChefe private constructor(val origem: String) {
    companion object {
        fun deToque(origem: String): ComandoDoChefe = ComandoDoChefe(origem)
    }
}

object PoliticaDeControle {
    const val MICROFONE_SO_SOB_COMANDO = true
    const val CAMERA_SO_SOB_COMANDO = true

    fun microfonePermitido(c: Config): Boolean = c.microfone
    fun cameraPermitida(c: Config): Boolean = c.camera
}
